﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class AddViewCodeLink : System.Web.UI.Page
{
    //code add to file
    public string strCode = "<!-- #include file = \"ViewCode.inc\"-->";
    //the list of file need to add links.
    public string strWarming;
    //List the Files to warming the operator.
    public ArrayList alCodeToAddFileList = new ArrayList();
    //list of file added link this time.
    public ArrayList alAddedFileList = new ArrayList();
    //files had been added the ViewCode Link(not this time)
    public ArrayList alAlreadyAddedFileList = new ArrayList();
    //files failed to add link
    public ArrayList alFailedToAdd = new ArrayList();
    protected void Page_Load(object sender, EventArgs e)
    {
        string strCurrDir = Path.GetDirectoryName(HttpContext.Current.Server.MapPath(Path.GetFileName(Page.Request.FilePath.ToString())));
        get_Curr_Dir_ASPX_html_htmFileList(strCurrDir);
        if (alCodeToAddFileList.Count > 0)
        {
            strWarming = "<h3>These files will add ViewCode Link:</h3><ul>";
            foreach (object FN in alCodeToAddFileList)
            {
                string stronlyFN = Path.GetFileName(FN.ToString());
                strWarming += "<li><a href = \"" + stronlyFN + "\">" + stronlyFN + "</a></li>";
            }
            strWarming += "</ul>";
        }
        if (alAlreadyAddedFileList.Count > 0)
        {
            strWarming += "<h3>These files had been added: :</h3><ul>";
            foreach (object FN in alAlreadyAddedFileList)
            {
                string stronlyFN = Path.GetFileName(FN.ToString());
                strWarming += "<li><a href = \"" + stronlyFN + "\">" + stronlyFN + "</a></li>";
            }
            strWarming += "</ul>";
        }
    }
    public void get_Curr_Dir_ASPX_html_htmFileList(string strCurrDir)
    {
        foreach (string FN in Directory.GetFiles(strCurrDir))
        {
            string strFNLowCase = FN.ToString().ToLower();
            if (isLinkAdded(FN))
            {
                alAlreadyAddedFileList.Add(FN);
            }
            else
            {
                if ((strFNLowCase.EndsWith("aspx")) && !strFNLowCase.EndsWith("viewcode.aspx") && !strFNLowCase.EndsWith("addviewcodelink.aspx"))
                {
                    alCodeToAddFileList.Add(FN);
                }
            }
        }
        foreach (string DN in Directory.GetDirectories(strCurrDir))
        {
            get_Curr_Dir_ASPX_html_htmFileList(DN);
        }
    }
    //add code to a single ASPX file
    public int addCodeInEnd(string strFileName)
    {
        if (isLinkAdded(strFileName))
        {
            return 0;
        }
        try
        {
            StreamWriter sw = File.AppendText(strFileName);
            sw.WriteLine(strCode);
            sw.Flush();
            sw.Close();
            return 1;
        }
        catch(Exception ee)
        {
            strWarming = "StreamWriter need more permission! </br>" + ee.Message;
        }
        return 2;
    }
    public bool isLinkAdded(string strFileName)
    {
        StreamReader sr = new StreamReader(strFileName);
        string strLastLine = "";
        while (!sr.EndOfStream)
        {
            strLastLine = sr.ReadLine();
        }
        if (strLastLine == strCode)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        foreach (object FN in alCodeToAddFileList)
        {
            if (addCodeInEnd(FN.ToString()) == 0)
            {
                alAlreadyAddedFileList.Add(FN);
            }
            else if (addCodeInEnd(FN.ToString()) == 1)
            {
                alAddedFileList.Add(FN);
            }
            else
            {
                alFailedToAdd.Add(FN);
            }
        }
        if (alAddedFileList.Count > 0)
        {
            strWarming = "<h3>Add Links in these Files:</h3><ul>";
            foreach (object FN in alAddedFileList)
            {
                string stronlyFN = Path.GetFileName(FN.ToString());
                strWarming += "<li><a href = \"" + stronlyFN + "\">" + stronlyFN + "</a></li>";
            }
            strWarming += "</ul>";
        }
        if (alAlreadyAddedFileList.Count > 0)
        {
            strWarming += "<h3>These files had been added: :</h3><ul>";
            foreach (object FN in alAlreadyAddedFileList)
            {
                string stronlyFN = Path.GetFileName(FN.ToString());
                strWarming += "<li><a href = \"" + stronlyFN + "\">" + stronlyFN + "</a></li>";
            }
            strWarming += "</ul>";
        }
        if (alFailedToAdd.Count > 0)
        {
            strWarming += "<h3>These files had failed to add links: :</h3><ul>";
            foreach (object FN in alFailedToAdd)
            {
                string stronlyFN = Path.GetFileName(FN.ToString());
                strWarming += "<li><a href = \"" + stronlyFN + "\">" + stronlyFN + "</a></li>";
            }
            strWarming += "</ul>";
        }
    }
    protected void btnReFresh_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddViewCodeLink.aspx");
    }
}
