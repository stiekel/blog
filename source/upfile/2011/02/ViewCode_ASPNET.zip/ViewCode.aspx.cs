﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class ViewSource : System.Web.UI.Page
{
    //the code of file
    public string strCode = "code here";
    //full path of file
    public string strFileName = "nopath";
    //File List(HTML)
    public string strFileList = "";
    //full path of the file in the list
    public ArrayList alFileList = new ArrayList();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Params["txtPath"] != null )
        {
            strFileName = Request.Params["txtPath"];
        }
        else if (Server.UrlDecode(Request.QueryString["clickPath"]) != null)
        {
            strFileName = Server.UrlDecode(Request.QueryString["clickPath"]);
        }
        if (strFileName == "nopath")
        {
            strFileName = getFullPath() + ".cs";
        }
        getFileListInCurrDir(Path.GetDirectoryName(strFileName)) ;
        strFileList = "<ul>";
        foreach (object objFN in alFileList)
        {
            string FN = objFN.ToString();
            strFileList += "<li><a href = \"?clickPath=" + Server.UrlEncode(FN) + "\">" + Path.GetFileName(FN) + "</a></li>";
        }
        strFileList += "</ul>";
        if (File.Exists(strFileName))
        {
            try
            {
                StreamReader sr = File.OpenText(strFileName);
                strCode = sr.ReadToEnd();
                sr.Close();
                txtPath.Text = strFileName;
                lblOpenWarming.Text = "";
            }
            catch (Exception ee)
            {
                strCode = "\"" + strFileName + "\" is not a text file, or it was to long.";
                strCode += ee.Message;
                lblOpenWarming.Text = "open error!";
            }
        }
        else
        {
            strCode = "\"" + strFileName + "\" is not exists!";
            lblOpenWarming.Text = "file not exists!";
            txtPath.Text = getFullPath() + ".cs";
        }

        SetFocus(txtPath);
    }
   public string getFullPath()
    {
        return HttpContext.Current.Server.MapPath(Path.GetFileName(Page.Request.FilePath.ToString()));
    }
    public void getFileListInCurrDir(string strCurrDir)
    {
        foreach (string FN in Directory.GetFiles(strCurrDir))
        {
            string strFNLowCase = FN.ToString().ToLower();
            if (strFNLowCase.EndsWith("aspx") || strFNLowCase.EndsWith("cs") || strFNLowCase.EndsWith("txt") || strFNLowCase.EndsWith("ascx") || strFNLowCase.EndsWith("master") || strFNLowCase.EndsWith("config") || strFNLowCase.EndsWith("html") || strFNLowCase.EndsWith("htm") || strFNLowCase.EndsWith("css"))
            {
                alFileList.Add(FN.ToString());
            }
        }
        foreach (string DN in Directory.GetDirectories(strCurrDir))
        {
            getFileListInCurrDir(DN);
        }
    }
    protected void brown_Click(object sender, EventArgs e)
    {
        strFileName = strFileName.ToLower();
        if (strFileName.EndsWith("aspx") || strFileName.EndsWith("html") || strFileName.EndsWith("htm")) 
        {
            Response.Redirect(Path.GetFileName(strFileName));
        }
        else
        {
            lblOpenWarming.Text = "view aspx page only!";
        }
    }
}
